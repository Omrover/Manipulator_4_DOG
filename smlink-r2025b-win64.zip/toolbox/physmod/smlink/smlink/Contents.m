% Simscape Multibody Link
% Version 25.2 (R2025b) 28-Jul-2025

%   Copyright 2007-2025 The MathWorks, Inc.
